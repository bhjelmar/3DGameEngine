package com.appdynamics;

import org.appdynamics.appdrestapi.RESTAccess;
import org.appdynamics.appdrestapi.data.Application;
import org.appdynamics.appdrestapi.data.IPAddress;
import org.appdynamics.appdrestapi.data.Node;
import org.appdynamics.appdrestapi.data.Tier;

import java.util.Arrays;
import java.util.List;

public class Main {

    public static void main(String[] args) {

        String user="ugbh163";
        String passwd="Alex95785362";
        String account="customer1";

        List<String> controllers = Arrays.asList("http://ga016vaaa5.suntrust.com",
                "http://ga016vaaa6.suntrust.com",
                "http://ga016vaaf1.suntrust.com",
                "http://ga016vab00.suntrust.com",
                "http://nc006vqaade1",
                "http://nc006vqaade2",
                "http://nc006vqaade3",
                "http://nc006vqaade4");

        for(String controller : controllers) {
            RESTAccess access = new RESTAccess(controller, "8090",false, user, passwd, account);
            for(Application application : access.getApplications().getApplications()) {
                System.out.println(application.getName());
                for(Tier tier : access.getTiersForApplication(application.getId()).getTiers()) {
                    System.out.println("\t" + tier.getName());
                    for(Node node : access.getNodesFromTier(application.getName(), tier.getName()).getNodes()) {
                        System.out.println("\t\t" + node.getName());
                        for(IPAddress ipAddress : node.getIpAddresses().getIpaddresses()) {
                            System.out.println("\t\t\t" + ipAddress.getIpAddress());
                        }
                    }
                }
            }
        }
    }
}
